package android.bootcamp.cps499_asgn8;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{
    private Button btnMJ, btnTheWeeknd, btnEminem;

    private MediaPlayer mpMJ, mpTheWeeknd, mpEminem;

    private int playing;

    private static final int NOT_PLAYING=0, PLAYING=1;

    private static final String MJ_PLAYING = "Pause MJ", MJ_PAUSED = "Play MJ",
                                THEWEEKND_PLAYING = "Pause The Weeknd", THEWEEKND_PAUSED = "Play The Weeknd",
                                EMINEM_PLAYING = "Pause Eminem", EMINEM_PAUSED = "Play Eminem";


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnMJ = (Button)findViewById(R.id.btnMJ);
        btnTheWeeknd = (Button)findViewById(R.id.btnTheWeeknd);
        btnEminem = (Button)findViewById(R.id.btnEminem);

        btnMJ.setOnClickListener(btnMJListener);
        btnTheWeeknd.setOnClickListener(btnTheWeekndListener);
        btnEminem.setOnClickListener(btnEminemListener);

        mpMJ = new MediaPlayer();
        mpMJ = MediaPlayer.create(this, R.raw.babybemine);

        mpTheWeeknd = new MediaPlayer();
        mpTheWeeknd = MediaPlayer.create(this, R.raw.wickedgames);

        mpEminem = new MediaPlayer();
        mpEminem = MediaPlayer.create(this, R.raw.threeonethree);

        playing = NOT_PLAYING;
    }

    View.OnClickListener btnMJListener = new View.OnClickListener()
    {

        @Override
        public void onClick(View view) {
            // determine mpUkelele's action based on playing state

            switch (playing) {
                case NOT_PLAYING:
                    mpMJ.start();
                    playing = PLAYING;

                    btnMJ.setText(MJ_PLAYING);

                    btnTheWeeknd.setVisibility(View.INVISIBLE);
                    btnEminem.setVisibility(View.INVISIBLE);
                    break;
                case PLAYING:
                    mpMJ.pause();
                    playing = NOT_PLAYING;

                    btnMJ.setText(MJ_PAUSED);

                    btnTheWeeknd.setVisibility(View.VISIBLE);
                    btnEminem.setVisibility(View.VISIBLE);
                    break;
            } // end switch
        }
    };

    View.OnClickListener btnTheWeekndListener = new View.OnClickListener()
    {

        @Override
        public void onClick(View view) {
            // determine mpUkelele's action based on playing state

            switch (playing) {
                case NOT_PLAYING:
                    mpTheWeeknd.start();
                    playing = PLAYING;

                    btnTheWeeknd.setText(THEWEEKND_PLAYING);

                    btnMJ.setVisibility(View.INVISIBLE);
                    btnEminem.setVisibility(View.INVISIBLE);
                    break;
                case PLAYING:
                    mpTheWeeknd.pause();
                    playing = NOT_PLAYING;

                    btnTheWeeknd.setText(THEWEEKND_PAUSED);

                    btnMJ.setVisibility(View.VISIBLE);
                    btnEminem.setVisibility(View.VISIBLE);
                    break;
            } // end switch
        }
    };

    View.OnClickListener btnEminemListener = new View.OnClickListener()
    {

        @Override
        public void onClick(View view) {
            // determine mpUkelele's action based on playing state

            switch (playing) {
                case NOT_PLAYING:
                    mpEminem.start();
                    playing = PLAYING;

                    btnEminem.setText(EMINEM_PLAYING);

                    btnMJ.setVisibility(View.INVISIBLE);
                    btnTheWeeknd.setVisibility(View.INVISIBLE);
                    break;
                case PLAYING:
                    mpEminem.pause();
                    playing = NOT_PLAYING;

                    btnEminem.setText(EMINEM_PAUSED);

                    btnMJ.setVisibility(View.VISIBLE);
                    btnTheWeeknd.setVisibility(View.VISIBLE);
                    break;
            } // end switch
        }
    };

}