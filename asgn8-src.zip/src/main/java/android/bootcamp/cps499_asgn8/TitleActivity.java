package android.bootcamp.cps499_asgn8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

public class TitleActivity extends AppCompatActivity
{
    private static final long DELAY = 6000;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_title);

        TimerTask task = new TimerTask()
        {
            @Override
            public void run()
            {
               finish();

               Intent mainIntent = new Intent(TitleActivity.this, MainActivity.class);
               startActivity(mainIntent);
            }
        };

        Timer opening = new Timer();
        opening.schedule(task, DELAY);
    }
}