package android.bootcamp.ndaom1_asgn04;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends Activity {

    private final float PESO_CONVERT_RATE = (float) 20.43;
    private final float CAN_CONVERT_RATE = (float) 1.24;
    private final float EUR_CONVERT_RATE = (float) .84;

    private final int DOLLAR_LIMIT = 100000;
    private float dollarsEntered;
    private double convertedCur;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnConvert = (Button)findViewById(R.id.btnConvert);

        View.OnClickListener btnConvertListener = new View.OnClickListener() {
            final EditText txtDollars = (EditText)findViewById(R.id.txtDollars);
            final RadioButton dllrsToPss = (RadioButton)findViewById(R.id.dllrsToPss);
            final RadioButton dllrsToErs = (RadioButton)findViewById(R.id.dllrsToErs);
            final RadioButton dllrsToCdllrs = (RadioButton)findViewById(R.id.dllrsToCdllrs);
            final TextView txtResult = (TextView)findViewById(R.id.txtResult);

            final DecimalFormat formatter = new DecimalFormat("##.##");
            @Override
            public void onClick(View v) {
                String InputString = txtDollars.getText().toString();
                String OutputString = "Invalid Data Entered";

                try
                {
                    dollarsEntered = Float.parseFloat(InputString);

                    if (dllrsToPss.isChecked())
                    {
                        if (dollarsEntered <= DOLLAR_LIMIT)
                        {
                            convertedCur = (dollarsEntered * PESO_CONVERT_RATE);
                            OutputString = formatter.format(convertedCur);
                        }
                    }
                    if (dllrsToErs.isChecked())
                    {
                        convertedCur = (dollarsEntered * EUR_CONVERT_RATE);
                        OutputString = formatter.format(convertedCur);
                    } else
                        {
                            if (dollarsEntered <= DOLLAR_LIMIT)
                            {
                                convertedCur = (dollarsEntered * CAN_CONVERT_RATE);
                                OutputString = formatter.format(convertedCur);
                            }
                        }
                } catch (Exception ex)
                {
                    Toast ewToast = Toast.makeText(MainActivity.this, ex.toString(),
                                                    Toast.LENGTH_LONG);
                }
                txtResult.setText(OutputString);
            }
        };
        btnConvert.setOnClickListener(btnConvertListener);
    }
}