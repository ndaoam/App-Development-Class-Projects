package android.bootcamp.cps499_asgn3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn_Intro = (Button)findViewById(R.id.btn_Intro);

        View.OnClickListener buttonListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent activity_main2 = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(activity_main2);
            }
        };
        btn_Intro.setOnClickListener(buttonListener);
    }
}