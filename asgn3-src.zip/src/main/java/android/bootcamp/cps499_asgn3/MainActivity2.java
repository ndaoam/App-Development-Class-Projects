package android.bootcamp.cps499_asgn3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity2 extends AppCompatActivity {
    private int numofCostumers;
    private float costofBill;
    private String ratingChoice;
    private float finalCost;
    private float waiterTip;
    private float requiredTip;
    private String s = "";
    private float excellentTip = (float) .2;
    private float averageTip = (float) .15;
    private float poorTip = (float) .1;
    private String ratingResponse;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        final Button BTN_BILL = (Button)findViewById(R.id.btn_Bill);
        assert BTN_BILL != null;

        View.OnClickListener btnBillListener = new View.OnClickListener() {

            final EditText num_Of_Customers = (EditText)findViewById(R.id.num_Of_Customers);
            final EditText cost_of_bill = (EditText)findViewById(R.id.cost_of_bill);
            final Spinner txtRating = (Spinner)findViewById(R.id.txtRating);
            final TextView txtResult = (TextView)findViewById(R.id.txtResult);
            @Override
            public void onClick(View v) {
                Editable Input = num_Of_Customers.getText();
                String InputString = Input.toString();

                Editable Input2 = cost_of_bill.getText();
                String Input2String = Input2.toString();

                try {
                    numofCostumers = Integer.parseInt(InputString);
                    costofBill = Integer.parseInt(Input2String);
                    ratingChoice = txtRating.getSelectedItem().toString();

                    if (ratingChoice.equals("Excellent")) {
                        waiterTip = excellentTip;
                        ratingResponse = "One of the best meals ever!  I will recommend this place to everyone I know!";
                    }
                    if (ratingChoice.equals("Average")) {
                        waiterTip = averageTip;
                        ratingResponse = "Everything was OK";
                    }
                    if (ratingChoice.equals("Poor")) {
                        waiterTip = poorTip;
                        ratingResponse = "Awful! The worst! I can't wait to give negative reviews on Yelp!";
                    }

                    DecimalFormat currency = new DecimalFormat("$###,###.##");

                    finalCost = costofBill / numofCostumers;
                    requiredTip = finalCost * waiterTip;

                    String OutputString = "Individual Cost is " + currency.format(finalCost) + ". Individual Tip is " + currency.format(requiredTip) + ". Response is: " + ratingResponse;
                    txtResult.setText(OutputString);
                } catch (Exception e) {
                    Log.e(e.getMessage(), e.toString());
                }
            }
        };
       BTN_BILL.setOnClickListener(btnBillListener);
    }
}