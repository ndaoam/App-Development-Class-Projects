package android.bootcamp.cps499asgn7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private int tripLength, boardHr, boardMin;
    public static final String  TRIPLENGTH_KEY = "key1", ARRHOUR_KEY="key2", ARRMIN_KEY="key3";
    private SharedPreferences sharedPref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnArrival = (Button)findViewById(R.id.btnArrival);
        sharedPref = PreferenceManager.getDefaultSharedPreferences(this);




        View.OnClickListener btnArrivalListener = new View.OnClickListener() {
            EditText txtTripLength = (EditText)findViewById(R.id.tripLength);
            EditText txtBoardingHr = (EditText)findViewById(R.id.boardingTimeHrs);
            EditText txtBoardingMin = (EditText)findViewById(R.id.boardingTimeMin);

            private boolean validTripLength (int input) {
                return (input > 0 && input < 1500);
            }
            private boolean validBoardingHours (int input) {
                return (input >= 0 && input < 24);
            }
            private boolean validBoardingMin (int input) {
                return (input >= 0 && input < 60);
            }
            @Override
            public void onClick(View view) {
                String triplengthAmt = txtTripLength.getText().toString();
                String BoardMinAmt = txtBoardingMin.getText().toString();
                String BoardHrAmt = txtBoardingHr.getText().toString();

                int tripLengthNum = Integer.parseInt(triplengthAmt);
                int BoardMinNum = Integer.parseInt(BoardMinAmt);
                int BoardHrNum = Integer.parseInt(BoardHrAmt);
                int arrTimeHr;
                int arrTimeMin;

                int dumHr = tripLengthNum / 60;
                arrTimeHr = BoardHrNum + dumHr;
                SharedPreferences.Editor editor = sharedPref.edit();

                editor.putInt(TRIPLENGTH_KEY, tripLengthNum);
                editor.putInt(ARRHOUR_KEY, arrTimeHr);
                editor.putInt(ARRMIN_KEY, BoardHrNum);
                int showATH = sharedPref.getInt(ARRHOUR_KEY, arrTimeHr);
                int showATM = sharedPref.getInt(ARRMIN_KEY, BoardMinNum);

                editor.commit();

                Intent intent = new Intent(MainActivity.this, ArrivalActivity.class);
                startActivity(intent);
            }
        };
        btnArrival.setOnClickListener(btnArrivalListener);

    }

}

