package android.bootcamp.cps499asgn7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.TextView;

import java.text.DecimalFormat;

public class ArrivalActivity extends AppCompatActivity {
    private SharedPreferences sharedPref;
    private final DecimalFormat currency = new DecimalFormat("##:##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arrival);

        sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        TextView arrTime = (TextView)findViewById(R.id.arrTime);



    }
}