package android.bootcamp.cps499_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SportsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sports);
        // Each Button creates an on click listener that opens a browser to a website to read the manga
        // Code derived from https://stackoverflow.com/questions/5026349/how-to-open-a-website-when-a-button-is-clicked-in-android-application/25946612
        Button slamdunkBtn = (Button) findViewById(R.id.slamdunkBtn);
        slamdunkBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                // Link to Slam Dunk manga website
                intent.setData(Uri.parse("https://mangaowl.net/single/60/faq.html"));
                startActivity(intent);
            }
        });
        Button runwiththewindBtn = (Button) findViewById(R.id.runwiththewindBtn);
        runwiththewindBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                // Link to Run with the wind manga website
                intent.setData(Uri.parse("https://mangafast.net/read/run-with-the-wind"));
                startActivity(intent);
            }
        });
        Button haikyuuBtn = (Button) findViewById(R.id.haikyuuBtn);
        haikyuuBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                // Link to Haikyuu Manga
                intent.setData(Uri.parse("https://haikyuumanga-online.com/"));
                startActivity(intent);
            }
        });
    }
}