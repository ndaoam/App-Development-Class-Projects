package android.bootcamp.cps499_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SeinenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seinen);
        // Each Button creates an on click listener that opens a browser to a website to read the manga
        // Code derived from https://stackoverflow.com/questions/5026349/how-to-open-a-website-when-a-button-is-clicked-in-android-application/25946612
        // The Intent object with the set action and category browsable values should open up a browser to said website
        Button berserkBtn = (Button) findViewById(R.id.berserkBtn);
        berserkBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                // Link to berserk manga website
                intent.setData(Uri.parse("https://readberserk.com/"));
                startActivity(intent);
            }
        });
        Button cowboybebopBtn = (Button) findViewById(R.id.cowboybebopBtn);
        cowboybebopBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                // Link to cowboy bebop manga website
                intent.setData(Uri.parse("https://m.manganelo.com/manga-vr93337"));
                startActivity(intent);
            }
        });
        Button vagabondBtn = (Button) findViewById(R.id.vagabondBtn);
        vagabondBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                // Link to vagabond manga website
                intent.setData(Uri.parse("https://readvagabond.com/"));
                startActivity(intent);
            }
        });
    }
}