package android.bootcamp.cps499_final;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import android.widget.Button;
import android.widget.EditText;


import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setting layout file
        setContentView(R.layout.activity_main);
        // create buttons for opening different activities of the apps
        Button sportsBtn = (Button)findViewById(R.id.sportsBtn);
        Button seinenBtn = (Button)findViewById(R.id.seinenBtn);
        Button shounenBtn = (Button)findViewById(R.id.shounenBtn);
        Button ratingBtn = (Button)findViewById(R.id.ratingBtn);
        // Button Action to go to Sports Page
        View.OnClickListener sportsBtnListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sportsIntent = new Intent(MainActivity.this, SportsActivity.class);
                startActivity(sportsIntent);
            }
        };
        sportsBtn.setOnClickListener(sportsBtnListener);
        // Button Action to go to Seinen Page
        View.OnClickListener seinenBtnListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent seinenIntent = new Intent(MainActivity.this, SeinenActivity.class);
                startActivity(seinenIntent);
            }
        };
        seinenBtn.setOnClickListener(seinenBtnListener);
        // Button Action to go to Shounen Page
        View.OnClickListener shounenBtnListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shounenIntent = new Intent(MainActivity.this, ShounenActivity.class);
                startActivity(shounenIntent);
            }
        };
        shounenBtn.setOnClickListener(shounenBtnListener);

        // Search Bar for implicit intent on manga search, it's supposed to launch an action view of a chrome browser.
        // Code derived from https://www.geeksforgeeks.org/android-implicit-and-explicit-intents-with-examples/ & https://www.concretepage.com/android/android-implicit-intent-example-open-url-in-browser-make-phone-call
        EditText searchBar = (EditText)findViewById(R.id.searchBar);
        Button searchBtn = (Button)findViewById(R.id.searchBtn);

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String url = searchBar.getText().toString();
               url = "http://www." + url;
               Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
               startActivity(intent);
            }
        });

        View.OnClickListener ratingBtnListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent rateIntent = new Intent(MainActivity.this, RateActivity.class);
                startActivity(rateIntent);
            }
        };
        ratingBtn.setOnClickListener(ratingBtnListener);

    }


}