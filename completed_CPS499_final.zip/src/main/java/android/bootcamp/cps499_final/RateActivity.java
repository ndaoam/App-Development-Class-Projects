package android.bootcamp.cps499_final;

import android.app.ListActivity;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.List;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

// Basic ListActivity, code derived from: https://examples.javacodegeeks.com/android/core/app/listactivity/android-listactivity-example/

public class RateActivity extends ListActivity {
    private TextView text;
    private List<String> listValues;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate);

        text = (TextView) findViewById(R.id.ratingTextView);

        listValues = new ArrayList<String>();
        listValues.add("Terrible");
        listValues.add("Bad");
        listValues.add("Alright");
        listValues.add("Good");
        listValues.add("Terrific");

        // initiate the listadapter
        ArrayAdapter<String> myAdapter = new ArrayAdapter <String>(this,
                R.layout.row_layout, R.id.listText, listValues);

        // assign the list adapter
        setListAdapter(myAdapter);

    }

    // when an item of the list is clicked
    @Override
    protected void onListItemClick(ListView list, View view, int position, long id) {
        super.onListItemClick(list, view, position, id);

        String selectedItem = (String) getListView().getItemAtPosition(position);
        //String selectedItem = (String) getListAdapter().getItem(position);

        text.setText(selectedItem);
    }

}

