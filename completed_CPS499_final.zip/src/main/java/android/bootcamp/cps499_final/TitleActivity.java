package android.bootcamp.cps499_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

public class TitleActivity extends AppCompatActivity
{
    // delay for title Screen
    private static final long DELAY = 5000;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_title);

        TimerTask task = new TimerTask()
        {
            @Override
            // method for creating intent
            public void run()
            {
                finish();

                Intent mainIntent = new Intent(TitleActivity.this, MainActivity.class);
                startActivity(mainIntent);
            }
        };
        Timer opening = new Timer();
        opening.schedule(task, DELAY);
    }
}